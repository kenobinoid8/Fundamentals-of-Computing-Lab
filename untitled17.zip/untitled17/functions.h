//
// Created by reyeltss on 10/25/2018.
//

#ifndef UNTITLED17_FUNCTIONS_H
#define UNTITLED17_FUNCTIONS_H

int* allocateArray(int arraySize);
int* increaseArray(int* array, int &currentSize, int IncreaseBy);
void listArray(int array[], int size);

#endif //UNTITLED17_FUNCTIONS_H
