#include <iostream>

using namespace std;

double* allocateArray(double arraySize)
{
    double *arrayPtr;
    arrayPtr = new double[arraySize];
    return arrayPtr;
}

double calculateAverage(double arry[], int size){
    double sum = 0;
    double average;
    int count = 0;
    for(int i = 0; i < size; i++){
        sum = sum + arry[i];
        count++;
    }

    average = sum / count;
    return average;
}

int main() {

    double *arrayPtr;
    int size = 5;
    arrayPtr = allocateArray(size);
    double userInput;

    for(int i = 0; i < size; i++){
        cin >> userInput;
        arrayPtr[i] = userInput;
    }

    calculateAverage(arrayPtr, size);




    return 0;
}