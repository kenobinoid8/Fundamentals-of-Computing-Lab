#include <iostream>
#include <cstring>
using namespace std;

char* reverse(char arr[ ], const int size){
    char* rev_str = new char[size];
    for(int i = 0; i < size - 1; i++){

        rev_str[i] = arr[size - i - 2];

    }
    return rev_str;

}  //returns the reverse of arr
void print(char arr[ ], const int size){

}
int main() {

    char my_message[] = {'G','R','A','V','I','T','Y','\0'};
    char* reverse_str = reverse(my_message,8);


    return 0;
}