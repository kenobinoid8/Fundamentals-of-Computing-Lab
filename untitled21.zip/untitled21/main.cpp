#include <iostream>
#include <string>

using namespace std;

char* cypher (string str, int rotate){
    char* enc_str = new char[str.size()];
    for(int i = 0; i <str.size(); i++){
        int ascii_value = int(str[i]);
        int new_ascii_value = ascii_value + rotate;

        //check new_ascii_value
        if(new_ascii_value > 122){
            int remain_value = new_ascii_value -122;
            new_ascii_value = 64 + remain_value;
        }

        enc_str[i] = char(new_ascii_value);
    }
    return enc_str;
}

int main() {

    string password = "p123";
    char* encrypt_pass = cypher(password, 1);
    puts(encrypt_pass);

    return 0;
}